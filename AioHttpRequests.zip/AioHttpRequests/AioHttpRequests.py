from time import sleep
from fake_useragent import UserAgent
from aiohttp import ClientSession, ClientTimeout
import asyncio
from WriteAndReadFiles import WriteAndReadJSON

class AioHttpRequests:
	def __init__(self, use_fake_user_agent=False, use_proxies=False, proxies_list=[]):
		self.__USE_FAKE_USER_AGENT = use_fake_user_agent
		self.__USE_PROXIES = use_proxies
		self.__PROXIES = proxies_list
		self.__URLS = []
		self.__HEADERS = {}
		self.__COOKIES = {}
		self.__WriteAndReadJSON = WriteAndReadJSON(filename=f'TimeoutErrorUrlsList')

	async def __requestController(self):
		if self.__USE_FAKE_USER_AGENT == True:
			self.__HEADERS['user-agent'] = UserAgent().random
		
	async def __fetchData(self, session, url, retry=5):
		await self.__requestController()

		try:
			async with session.get(url, headers=self.__HEADERS, timeout=300) as response:
				return await response.text(encoding='utf-8')
		except asyncio.TimeoutError:
			if retry:
				sleep(3)
				print(f'[INFO] retry={retry} => {url}')
				return await self.__fetchData(session, url, retry=(retry-1))
			else:
				self.__WriteAndReadJSON.append_object({'TimeoutError', url})
				return 'TimeoutError'
			
	async def __setTasks(self, session):
		tasks = []
		
		for url in self.__URLS:
			task = asyncio.create_task(self.__fetchData(session, url))
			tasks.append(task)
			
		return await asyncio.gather(*tasks)
		
	async def __createSession(self):
		timeout = ClientTimeout(total=1000000)
		async with ClientSession(timeout=timeout, cookies=self.__COOKIES) as session:
			return await self.__setTasks(session)
		
	def run(self, urls, headers={}, cookies={}):
		self.__URLS = urls
		self.__HEADERS = headers
		self.__COOKIES = cookies

		response = asyncio.run(self.__createSession())

		response_list = []

		for r in response:
			if r != 'TimeoutError':
				response_list.append(r)

		return response_list