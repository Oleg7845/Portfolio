import time

start = time.time() ## точка отсчета времени



end = time.time() - start ## собственно время работы программы

print(end) ## вывод времени