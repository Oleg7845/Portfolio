#1. Done -> Async replication
#2. Done -> If file exists on server do not save file and send message to client that client mast rename file
#3. Output messages like in technical task from Boss
#4. Cosmetic refactoring



import threading



