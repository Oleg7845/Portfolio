from ElGamalEncryption import ElGamal

ElGamal = ElGamal()

def Sender():
	Data = {"body": "Hi, Bob! Happy New Year!:))"}
	
	hello_req = {"category": "request", "type": "hello", "data": ElGamal.get_data_size(Data)}
	
	PublicKey = Receiver(hello_req)
	
	EncryptedData = ElGamal.encrypt(PublicKey, Data)
	
	send_req = {"category": "request", "type": "send_data", "data": EncryptedData}
	
	print(f'[Alice]\nOriginal data: {Data}\n\nPublic key from [Bob]:\n{PublicKey}\n\nEncrypted data:\n{EncryptedData}\n\n')
	
	Receiver(send_req)
	
def Receiver(msg):
	if msg["category"] == "request" and msg["type"] == "hello":
		return ElGamal.get_public_key(msg["data"])
	
	if msg["category"] == "request" and msg["type"] == "send_data":
		PrivateKey = ElGamal.get_private_key()
		
		DecryptedData = ElGamal.decrypt(PrivateKey, msg["data"])

		print(f'[Bob]:\nPrivate key: {PrivateKey}\n\nEncrypted data from [Alice]:\n{msg["data"]}\n\nDecrypted data from [Alice]:\n{DecryptedData}\n"body": {DecryptedData["body"]}')

def main():
	Sender()

if __name__ == "__main__":
	main()