from ElGamalEncryption.Models import DataSizeModel

class DataSize:
	def get_size(self, data: dict) -> DataSizeModel:
		return {'size': len(str(data))}