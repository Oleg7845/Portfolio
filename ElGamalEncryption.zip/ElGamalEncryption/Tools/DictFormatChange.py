import ast

class DictFormatChange:
	def dict_to_str(self, dictionary: dict) -> str:
		return str(dictionary)
	
	def str_to_dict(self, string: str) -> dict:
		return ast.literal_eval(string)