from .Tools import DataSize, DictFormatChange
from .MainAlgorithms import GenerateKeys, EncryptionAlgorithm
from .Models import *

class ElGamal:
	def __init__(self):
		self.__GenKeys = GenerateKeys()
		self.__EncryptAlg = EncryptionAlgorithm()
	
	def get_data_size(self, data: dict) -> DataSizeModel:
		return DataSize().get_size(data)
	
	def get_public_key(self, data_size: DataSizeModel) -> PublicKeyModel:
		return self.__GenKeys.get_public_key(data_size)
		
	def get_private_key(self) -> PrivateKeyModel:
		return self.__GenKeys.get_private_key()
		
	def encrypt(self, PublicKey: PublicKeyModel, Data: dict) -> EncryptedDataModel:
		return self.__EncryptAlg.encryption(PublicKey, Data)
		
	def decrypt(self, PrivateKey: PrivateKeyModel, Data: EncryptedDataModel) -> dict:
		return self.__EncryptAlg.decryption(PrivateKey, Data)
		
	def dict_to_str(self, dictionary: dict) -> str:
		return DictFormatChange().dict_to_str(dictionary)
		
	def str_to_dict(self, string: str) -> dict:
		return DictFormatChange().str_to_dict(string)