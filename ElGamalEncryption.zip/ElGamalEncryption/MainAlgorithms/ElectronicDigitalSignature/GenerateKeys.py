import Cryptodome.Util.number as num
import random
from typing import Tuple

class GenerateKeys:
    def __init__(self):
        self.__p: int = 0
        self.__g: int = 0

    def generate_pair(self, num_size: int) -> Tuple[int, int]:
        while(True):
            prime: int = num.getPrime(num_size)
            self.__p = 2 * prime + 1

            if(num.isPrime(self.__p)):
                break

        while(True):
              self.__g = random.randint(2, self.__p - 1)
              if((self.__p - 1) % self.__g != 1):
                break
            
        return self.__p, self.__g