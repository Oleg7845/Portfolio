from random import randint
import Cryptodome.Util.number as num
from Cryptodome.Hash import SHA512
from .GenerateKeys import GenerateKeys
from ...Models import *

class ElectronicDigitalSignature:
	def __init__(self):
		self.__GenKeys = GenerateKeys()
		self.__keys_size: int = 200
		self.__p: int = 0
		self.__g: int = 0
		self.__X: int = 0
		self.__Y: int = 0
		self.__A: int = 0
		self.__B: int = 0

	def __generate_keys(self):
		self.__p, self.__g = self.__GenKeys.generate_pair(self.__keys_size)
		self.__X = randint(1, self.__p - 2)
		self.__Y = pow(self.__g, self.__X, self.__p)
		
	def __get_string_hash(self, string: str) -> int:
		hex_hash = SHA512.new(data=string.encode()).hexdigest()
		return int(hex_hash, 16)
	
	def __generate_signature(self, m: str):
		self.__generate_keys()
		M: int = self.__get_string_hash(m)
	
		while 1:
			self.__k = randint(1, self.__p - 2)
			if num.GCD(self.__k, self.__p - 1) == 1: break
			
		self.__A = pow(self.__g, self.__k, self.__p)
		
		k1: int = num.inverse(self.__k, self.__p - 1)
		self.__B = k1 * (M - self.__X * self.__A) % (self.__p - 1)
		
	def add_signature(self, data: str) -> SignedDataModel:
		self.__generate_signature(data)
		
		return {
			'data': data,
			'signature': {
				'p': self.__p,
				'g': self.__g,
				'Y': self.__Y,
				'A': self.__A,
				'B': self.__B
			}
		}
	
	def verificate_signature(self, data: str, signature: SignatureModel) -> str | bool:
		p: int = signature['p']
		A: int = signature['A']
		
		M: int = self.__get_string_hash(data)
		
		if A < 1 or A > p - 1 : return False
		
		V1: int = pow(signature['Y'], A, p) % p* pow(A, signature['B'], p) % p
		V2: int = pow(signature['g'], M, p)

		if V1 == V2:
			return data
		else:
			return 'Signature is wrong!'