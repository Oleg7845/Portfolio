from random import randint
from Cryptodome.Util import number

class Prime:
	def generate(self, range_start: int, range_end: int, number_size: int) -> int:
		start: int = range_start * pow(10, number_size)
		end: int = range_end * pow(10, number_size)
		
		n: int = 0
			
		while not number.isPrime(n, 50):
			n: int = randint(start, end)
			if number.isPrime(n, 50):
				return n