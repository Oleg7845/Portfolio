from random import randint
from .Prime import Prime
from ...Models import *

class GenerateKeys:
	def __init__(self):
		self.__data_size: int = 0
		self.__p: int = 0
		self.__g: int = 0
		self.__Y: int = 0
		self.__PrivateKey: int = 0
	
	def __generate_numbers(self):
		self.__p = Prime().generate(1, 9, self.__data_size + 1)
		self.__g = randint(1001, 3000)
	
	def __generate_private_key(self):
		self.__generate_numbers()
		self.__PrivateKey = randint(100, 1000)
		
	def __generate_public_key(self):
		self.__generate_private_key()
		
		self.__Y: int = (self.__g ** self.__PrivateKey) % self.__p
		
	def get_public_key(self, data_size: DataSizeModel) -> PublicKeyModel:
		self.__data_size = data_size['size']
		self.__generate_public_key()
		
		return {'p': self.__p, 'g': self.__g, 'Y': self.__Y}
		
	def get_private_key(self) -> PrivateKeyModel:
		return {'key': self.__PrivateKey}