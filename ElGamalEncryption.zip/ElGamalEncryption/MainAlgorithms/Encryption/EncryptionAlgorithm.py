from random import randint
from ..ElectronicDigitalSignature import ElectronicDigitalSignature
from ...Tools import DictFormatChange
from ...ChangeDataFormat import ChangeDataFormat
from ...Models import *

class EncryptionAlgorithm:
	def __init__(self):
		self.__ElectronicDigitalSignature = ElectronicDigitalSignature()
		self.__DictFormatChange = DictFormatChange()
		self.__ChangeDataFormat = ChangeDataFormat()
	
	def encryption(self, PublicKey: PublicKeyModel, InputedData: dict) -> EncryptedDataModel:
		Data = self.__ChangeDataFormat.reformat(self.__DictFormatChange.dict_to_str(self.__ElectronicDigitalSignature.add_signature(self.__DictFormatChange.dict_to_str(InputedData))))

		k: int = randint(100, 500)
		
		A: int = PublicKey['g'] ** k % PublicKey['p']
		
		B: int = Data ^ (PublicKey['Y']**k % PublicKey['p'])
		
		return {'A': A, 'B': B, 'p': PublicKey['p']}
		
	def decryption(self, PrivateKey: PrivateKeyModel, EncryptedData: EncryptedDataModel) -> dict:
		DecryptedData = (EncryptedData['A'] ** PrivateKey['key'] % EncryptedData['p']) ^ EncryptedData['B']

		Data: dict = self.__DictFormatChange.str_to_dict(self.__ChangeDataFormat.reverse(DecryptedData))

		return self.__DictFormatChange.str_to_dict(self.__ElectronicDigitalSignature.verificate_signature(self.__DictFormatChange.dict_to_str(Data["data"]), Data["signature"]))