from typing import TypedDict

class EncryptedDataModel(TypedDict):
    A: int
    B: int
    p: int