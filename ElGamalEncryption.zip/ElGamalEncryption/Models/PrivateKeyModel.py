from typing import TypedDict

class PrivateKeyModel(TypedDict):
    key: int