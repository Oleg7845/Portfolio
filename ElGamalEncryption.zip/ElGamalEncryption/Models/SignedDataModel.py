from typing import TypedDict
from .SignatureModel import SignatureModel

class SignedDataModel(TypedDict):
    data: str
    signature: SignatureModel