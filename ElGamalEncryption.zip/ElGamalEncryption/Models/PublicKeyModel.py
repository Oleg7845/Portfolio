from typing import TypedDict

class PublicKeyModel(TypedDict):
    p: int
    g: int
    Y: int