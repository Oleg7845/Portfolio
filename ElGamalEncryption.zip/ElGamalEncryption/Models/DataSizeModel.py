from typing import TypedDict

class DataSizeModel(TypedDict):
    size: int