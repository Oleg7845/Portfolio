from typing import TypedDict

class SignatureModel(TypedDict):
    p: int
    g: int
    Y: int
    A: int
    B: int