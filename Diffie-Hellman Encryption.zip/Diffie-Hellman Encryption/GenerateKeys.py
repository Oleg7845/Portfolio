class GenerateKeys:
	def generate_public_key(self, a, g, p):
		PublicKey = (g**a)%p
		return PublicKey

	def generate_private_key(self, PublicKey, a, p):
	   	PrivateKey = (PublicKey**a)%p
	   	return PrivateKey