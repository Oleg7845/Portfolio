import json

class CharsDict:
	def __init__(self):
		self.__chars = ":;'@#&()[]{}<>=-+*/~`^%$|.,!?√π÷×∆∅°ⁿ⁰¹²³⁴⁵⁶⁷⁸⁹_0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеєёжзийклмнопрстуфхцчшщъыьэюяґіїє"
		self.__iterator = 100
		self.__iteration_step = 3
		self.__chars_dict = {}

	def __generate(self):
		self.__chars_dict['"'] = self.__iterator
		
		for char in self.__chars:
			self.__iterator += self.__iteration_step
			self.__chars_dict[char] = str(self.__iterator)

	def __write_to_file(self):
		self.__generate()
		with open('CharsDict/chars_with_number_associations.json', 'w') as outfile:
		  json.dump(self.__chars_dict, outfile)

	def get_dict(self):
		try:
			with open('CharsDict/chars_with_number_associations.json') as json_file:
				chars_dict = json.load(json_file)
		
			return chars_dict
		except:
			self.__write_to_file()
			return self.get_dict()
			
	def get_iteration_step(self):
		return self.__iteration_step