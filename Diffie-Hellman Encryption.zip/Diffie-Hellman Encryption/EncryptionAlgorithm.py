import sys
from CharsDict import CharsDict

CharsDict = CharsDict()

class EncryptionAlgorithm:
	def __init__(self):
		self.__chars_associations = CharsDict.get_dict()
		self.__iteration_step = CharsDict.get_iteration_step()

	#Encryption
	def encryption(self, incomming_string = '', secret_key = 0):
		str_as_num = ''
		
		for n in range(0, len(incomming_string)):
			str_as_num += str(self.__chars_associations[incomming_string[n]])
		
		encrypted_data = int(str_as_num) * secret_key
		bytes = sys.getsizeof(encrypted_data)
		length = len(str(encrypted_data))
		
		data_dict = {'data': encrypted_data, 'size': {'bytes': bytes, 'length': length}}
		
		return data_dict

	#Decription
	def decryption(self, incomming_number = 0, secret_key = 0):
		str_as_num = str(int(incomming_number // secret_key))
		start_index = 0
		end_index = self.__iteration_step
		string_out = ""
		
		for _ in range(0, len(str_as_num) // self.__iteration_step):
			for k,v in self.__chars_associations.items():
				if v == str_as_num[start_index:end_index]:
					string_out += k
			
			start_index += self.__iteration_step
			end_index += self.__iteration_step
		
		return string_out