import ast

class DictFormatChange:
	def dict_to_str(self, dict):
		return str(dict)
	
	def str_to_dict(self, str):
		return ast.literal_eval(str)