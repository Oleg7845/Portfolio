from GenerateNumber import GenerateNumber
from GenerateKeys import GenerateKeys
from EncryptionAlgorithm import EncryptionAlgorithm
from DictFormatChange import DictFormatChange

GenNum = GenerateNumber()
GenerateKeys = GenerateKeys()
EncryptAlg = EncryptionAlgorithm()
DictFormatChange = DictFormatChange()

p = GenNum.generate(2000, 6000)
g = GenNum.generate(500, 1000)

#User 1
a1 = GenNum.generate(1000, 3000) #Private key
r1 = GenerateKeys.generate_public_key(a1, p, g) #Public key

#User 2
a2 = GenNum.generate(1000, 3000)  #Private key
r2 = GenerateKeys.generate_public_key(a2, p, g)  #Public key

key1 = GenerateKeys.generate_private_key(r2, a1, p)
key2 = GenerateKeys.generate_private_key(r1, a2, p)

private_key = key1

block = {"body": {"data": "some data...bla-bla", "prev_hash": "fgsryieie73839485ijf"}, "hash": "dfy6546uug677tt"}

encrypted_message = EncryptAlg.encryption(DictFormatChange.dict_to_str(block), private_key)

decrypted_message = EncryptAlg.decryption(encrypted_message["data"], private_key)

print(f'Inputed data:\n{block}\n\nEncrypted data:\n{encrypted_message["data"]}\n\nDecrypted data:\n{DictFormatChange.str_to_dict(decrypted_message)["body"]}')