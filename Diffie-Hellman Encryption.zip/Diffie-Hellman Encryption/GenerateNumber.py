from random import randint

class GenerateNumber:
	def generate(self, start, stop):
	    mod_list = []
	
	    for num in range(start, stop):
	        if num > 1:
	            for i in range(2, num):
	                if (num % i) == 0:
	                    break
	            else:
	                mod_list.append(num)
	
	    x = randint(1, len(mod_list))
	    return mod_list[x]