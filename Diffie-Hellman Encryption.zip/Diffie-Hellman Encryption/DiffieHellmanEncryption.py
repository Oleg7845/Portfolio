from GenerateNumber import GenerateNumber
from GenerateKeys import GenerateKeys

class DHE:
	def __init__(self):
		self.__GenNum = GenerateNumber()
		self.__GenKeys = GenerateKeys()
		self.__a = 0
		self.__b = 0
		self.__p = 0
		self.__PrivateKey = 0
		
	def send_hello(self):
		self.__a = self.__GenNum.generate(1000, 3000)
		g = self.__GenNum.generate(500, 1000)
		self.__p = self.__GenNum.generate(2000, 6000)
		PublicKey = self.__GenKeys.generate_public_key(self.__a, g, self.__p)
		
		return {"g": g, "p": self.__p, "PublicKey": PublicKey}

	def received_answer_to_sand_hello(self, PublicKey_b):
		self.__PrivateKey = self.__GenKeys.generate_private_key(PublicKey_b, self.__a, self.__p)

	def reply_hello(self, hello):
		self.__p = hello["p"]
		self.__b = self.__GenNum.generate(1000, 3000)
		PublicKey = self.__GenKeys.generate_public_key(self.__b, hello["g"], self.__p)
		self.__PrivateKey = self.__GenKeys.generate_private_key(hello["PublicKey"], self.__b, self.__p)
		
		return PublicKey
		
	def get_private_key(self):
		return self.__PrivateKey