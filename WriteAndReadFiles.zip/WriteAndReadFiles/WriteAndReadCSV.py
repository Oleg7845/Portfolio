import csv

class WriteAndReadCSV:
    def __init__(self, directory='./', filename='file', titles=()):
        self.__FILENAME = filename
        self.__DIRECTORY = self.__init_directory(directory)
        self.__TITLES = titles
        self.__write_titles(self.__TITLES)

    def __init_directory(self, directory):
        if directory != './':
            return directory + '/'
        else:
            return directory

    def __open_file(self, directory, filename, mode='r'):
        return open(f'{self.__init_directory(directory)}{filename}.csv', mode=mode, newline='', encoding='utf-8')

    def __write_row(self, data, mode='a'):
        outfile = self.__open_file(self.__DIRECTORY, self.__FILENAME, mode)
        writer = csv.writer(outfile, delimiter=',')
        writer.writerow(data)

    def __write_titles(self, titles):
        if titles != ():
            self.__write_row(titles, 'w')

    def write_tuple(self, tuple=()):
        if tuple:
            self.__write_row(tuple)

    def write_tuples(self, tuples=()):
        if tuples:
            for tuple in tuples:
                self.__write_row(tuple)

    def write_list(self, list_=[]):
        if list_:
            self.__write_row(list_)

    def write_lists(self, lists=[]):
        if lists:
            for list in lists:
                self.__write_row(list)

    def write_dict(self, dict={}):
        if dict:
            self.__write_row(dict.values())

    def write_dicts(self, dicts_list=[]):
        if dicts_list:
            for dict in dicts_list:
                self.__write_row(dict.values())

    def read(self, directory='./', filename='file'):
        try:
            outfile = self.__open_file(directory, filename)
            reader = csv.reader(outfile, delimiter=',')
            rows_list = []

            for row in reader:
                if self.__TITLES != ():
                    object = {}
                    for i in range(len(row)):
                        object[self.__TITLES[i]] = row[i]

                    rows_list.append(object)
                else:
                    rows_list.append(row)

            return rows_list
        except FileNotFoundError:
            return []