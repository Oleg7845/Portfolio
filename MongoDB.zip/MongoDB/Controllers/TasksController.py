from MongoDB.Connection import DBConnection
from MongoDB.Models import Task

class TasksController:
    def __init__(self):
        self.__db = DBConnection()
        self.__collettion: str = "Tasks"

    def __Get_collection(self):
        return self.__db.getDatabase(self.__collettion)

    def GETAll(self):
        collection = self.__Get_collection()
        collection.co
        return collection.find()

    def GETOne(self, title: str) -> Task:
        collection = self.__Get_collection()
        return collection.find_one({"title": title})

    def POST(self, task: Task):
        collection = self.__Get_collection()
        collection.insert_one(task)

    def PUT(self, id: str):
        collection = self.__Get_collection()
        collection.insert_one(id)

    def DELETE(self, id: str):
        collection = self.__Get_collection()
        collection.insert_one(id)