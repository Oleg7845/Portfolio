from MongoDB.Connection import DBConnection
from MongoDB.Models import Shop

class ShopsController:
    def __init__(self):
        self.__db = DBConnection()
        self.__collettion: str = "Shops"

    def GETAll(self):
        pass

    def GETOne(self, id):
        pass

    def POST(self, id):
        pass

    def PUT(self, id):
        pass

    def DELETE(self, id):
        pass