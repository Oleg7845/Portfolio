from MongoDB.Connection import DBConnection
from MongoDB.Models import Recipe

class RecipesController:
    def __init__(self):
        self.__db = DBConnection()
        self.__collettion: str = "Recipes"

    def GETAll(self):
        pass

    def GETOne(self, id):
        pass

    def POST(self, id):
        pass

    def PUT(self, id):
        pass

    def DELETE(self, id):
        pass