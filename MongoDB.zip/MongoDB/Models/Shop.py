from typing import TypedDict
import datetime

class Shop(TypedDict):
    _id: str
    title: str
    price: float
    description: str
    creation_time: datetime.datetime