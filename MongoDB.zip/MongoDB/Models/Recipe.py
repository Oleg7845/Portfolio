from typing import TypedDict

class Recipe(TypedDict):
    _id: str
    title: str
    description: str