from enum import Enum
from typing import TypedDict
import datetime

class TaskStatus(Enum):
    TODO = "Active"
    DONE = "Completed"

class Task(TypedDict):
    _id: str
    title: str
    status: TaskStatus
    description: str
    creation_time: datetime.datetime