from pymongo import MongoClient

class DBConnection:
    def __init__(self):
        self.__login = "khayzenbergMongo_DB"
        self.__password = "HYmdExPYri2j0RUY"
        self.__db_name = "MyAssistant_25346Bot"

    def __getConnection(self):
        return MongoClient(f"mongodb+srv://{self.__login}:{self.__password}@cluster0.t9yaqrw.mongodb.net/?retryWrites=true&w=majority")

    def getDatabase(self, collection):
        client = self.__getConnection()
        db = client[self.__db_name]
        return db[collection]