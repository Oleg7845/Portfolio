from typing import TypedDict

class Product(TypedDict):
    title: str
    photo_link: str
    price_default: float
    #price_discount: float