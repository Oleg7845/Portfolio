from tqdm import tqdm
from AioHttpRequests import AioHttpRequests
from bs4 import BeautifulSoup as bs
from Product import Product
from WriteAndReadFiles import WriteAndReadEXCEL

class Parser:
	def __init__(self, language, target_directory='./'):
		self.__TARGET_DIRECTORY = self.__init_target_directory(target_directory)
		self.__AioHttp = AioHttpRequests(use_fake_user_agent=True)
		self.__BASE_URL = 'https://dok.ua'
		self.__PAGE_LANGUAGE = self.__setLanguage(language)

	def __init_target_directory(self, directory):
		if directory[-1] != './':
			return directory + '/'
		else:
			return directory

	def __setLanguage(self, language):
		if language == 'ua':
			return '/ua'
		else:
			return ''

	def __getSoup(self, data):
		return bs(data, 'lxml')

	def __parseRubricsLinks(self):
		response = self.__AioHttp.run(urls=[self.__BASE_URL + self.__PAGE_LANGUAGE])
		if response != []:
			soup = self.__getSoup(response[0])
			rubrics = soup.find_all('a', class_='menu-list__link')

			rubrics_links = []
			for rubric in rubrics:
				if self.__PAGE_LANGUAGE == 'ua':
					rubrics_links.append(self.__BASE_URL + rubric.get('href')[3:])
				rubrics_links.append(self.__BASE_URL + rubric.get('href'))

			return rubrics_links
		else:
			return response

	def __parseCatalogsLinks(self):
		rubrics = self.__parseRubricsLinks()
		catalog_links = []
		if rubrics != []:
			def appendLink(links):
				for link in links:
					link_url = link.get("href")
					if link_url != None:
						catalog_links.append(self.__BASE_URL + link_url)

			response = self.__AioHttp.run(urls=rubrics[:8])
			if response != []:
				for r in response:
					soup = self.__getSoup(r)
					links = soup.find_all('a', class_='menu-mob-level3__link')
					appendLink(links)

			response = self.__AioHttp.run(urls=rubrics[8:])
			if response != []:
				for r in response:
					soup = self.__getSoup(r)
					links = soup.find_all('a', class_='subHeading-block')
					appendLink(links)

			return list(set(catalog_links))
		else:
			return rubrics

	def __parseProductsLists(self, catalog_links, i):
		response = self.__AioHttp.run(urls=catalog_links[i:i+1])
		if response != []:
			for r in response:
				pages_links_in_catalog = []
				soup = self.__getSoup(r)
				catalog_link = soup.find('a', class_='language-switcher_link').get('href')[3:]
				pager_list = soup.find('ul', class_='pager__list')

				if pager_list != None:
					catalog_pages_count = int(pager_list.get('data-last-page'))

					for page_number in range(1, catalog_pages_count + 1):
						pages_links_in_catalog.append(f'{self.__BASE_URL}{self.__PAGE_LANGUAGE}{catalog_link}?page={page_number}')

				else:
					pages_links_in_catalog.append(f'{self.__BASE_URL}{self.__PAGE_LANGUAGE}{catalog_link}?page=1')

				return pages_links_in_catalog
		else:
			return response

	def __parseProductsCards(self):
		catalog_links = self.__parseCatalogsLinks()
		if catalog_links != []:
			print(f'Catalogs count: {len(catalog_links)}')

			for i in range(len(catalog_links)):
				if self.__PAGE_LANGUAGE == '/ua':
					catalog_title = catalog_links[i][26:]
				else:
					catalog_title = catalog_links[i][23:]

				print(f'Catalog title: {catalog_title}')

				pages_links_in_catalog = self.__parseProductsLists(catalog_links, i)

				pages = self.__AioHttp.run(urls=pages_links_in_catalog)
				for p in tqdm(range(len(pages))):
					soup = self.__getSoup(pages[p])
					catalog_row = soup.find('div', class_='catalog__product-list-row')

					if catalog_row != None:
						products_cards = catalog_row.find_all('div', class_='product-card')

						products_links = []
						for product_card in products_cards:
							product_link = product_card.find('a', class_='product-card__layout-name').get('href')
							products_links.append(self.__BASE_URL + product_link)

						products_list = []
						for product in self.__AioHttp.run(urls=products_links):
							soup = self.__getSoup(product)

							# Title
							# Photo link
							card_gallery = soup.find('div', id='card-gallery')
							if card_gallery != None:
								product_title = card_gallery.find('div', class_='card-gallery-big').find('img').get('alt')
								photo_link = card_gallery.find('div', class_='card-gallery-big').find('img').get('data-src')
							else:
								product_title = soup.find('div', class_='swiper-container').find('div', class_='swiper-zoom-container').find('img').get('alt')
								photo_link = soup.find('div', class_='swiper-container').find('div', class_='swiper-zoom-container').find('img').get('data-src')

							# price_default
							price_default = soup.find('div', class_='card-price-box__price').find('span', itemprop='price').get('content')

							# price_discount
							price_discount = None

							product_object = Product(
								title=product_title,
								photo_link=photo_link,
								price_default=float(price_default)
							)

							products_list.append(product_object)

						WriteAndReadEXCEL(
							directory=self.__TARGET_DIRECTORY,
							filename=f'{catalog_title}_{self.__PAGE_LANGUAGE[1:]}_page={p + 1}',
							titles=tuple(products_list[0].keys())
						).write_dicts(products_list)

	def recordProductsList(self):
		self.__parseProductsCards()