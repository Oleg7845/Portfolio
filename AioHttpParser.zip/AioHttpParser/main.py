from time import time
from Parser import Parser

def main():
    t0 = time()
    Parser('ua', 'C:\PythonDevelopment\AioHttpParser\pages').recordProductsList()
    print(f'Parsing time: {time() - t0}')

if __name__ == "__main__":
    main()