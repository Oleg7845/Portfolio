from openpyxl import Workbook
from openpyxl import load_workbook

class WriteAndReadEXCEL:
	def __init__(self, directory='./', filename='file', titles=()):
		self.__FILENAME = filename
		self.__DIRECTORY = self.__init_directory(directory)
		self.__TITLES = titles
		self.__BOOK = Workbook()
		self.__SHEET = self.__BOOK.active
		self.__row = 1
		self.__write_titles(self.__TITLES)

	def __init_directory(self, directory):
		if directory != './':
			return directory + '/'
		else:
			return directory

	def __seve_book(self):
		self.__BOOK.save(f'{self.__DIRECTORY}{self.__FILENAME}.xlsx')
		self.__BOOK.close()

	def __write_value(self, row, column, value):
		self.__SHEET.cell(row, column).value = value

	def __write_titles(self, titles):
		if titles != ():
			column = 1
			for title in titles:
				self.__write_value(1, column, title)
				column += 1
			self.__row += 1
			self.__seve_book()

	def write_tuple(self, tuple=()):
		if tuple:
			column = 1
			for item in tuple:
				self.__write_value(self.__row, column, item)
				column += 1
			self.__row += 1
			self.__seve_book()

	def write_tuples(self, tuples=()):
		if tuples:
			for tuple in tuples:
				column = 1

				for item in tuple:
					self.__write_value(self.__row, column, item)
					column += 1
				self.__row += 1
			self.__seve_book()

	def write_list(self, list_=[]):
		if list_:
			column = 1
			for item in list_:
				self.__write_value(self.__row, column, item)
				column += 1
			self.__row += 1
			self.__seve_book()

	def write_lists(self, lists=[]):
		if lists:
			for list in lists:
				column = 1

				for item in list:
					self.__write_value(self.__row, column, item)
					column += 1
				self.__row += 1
			self.__seve_book()

	def write_dict(self, dict={}):
		if dict:
			column = 1
			for key in dict:
				self.__write_value(self.__row, column, dict[key])
				column += 1
			self.__row += 1
			self.__seve_book()

	def write_dicts(self, dicts=[]):
		if dicts:
			for dict in dicts:
				column = 1

				for key in dict:
					self.__write_value(self.__row, column, dict[key])
					column += 1
				self.__row += 1
			self.__seve_book()

	def read(self, directory='./', filename='file'):
		try:
			workbook = load_workbook(f'{directory}{filename}.xlsx')
			for sheet_name in workbook.sheetnames:
				sheet = workbook[sheet_name]

				rows_list = []
				for tuple in sheet.iter_rows(values_only=True):
					if self.__TITLES != ():
						object = {}
						for i in range(len(tuple)):
							object[self.__TITLES[i]] = tuple[i]

						rows_list.append(object)
					else:
						list = []
						for item in tuple:
							list.append(item)
						rows_list.append(list)

				return rows_list
		except FileNotFoundError:
			return []