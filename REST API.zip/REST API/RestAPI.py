from fastapi import FastAPI, APIRouter
from Controllers import Tasks

app = FastAPI()
router = APIRouter()
app.include_router(Tasks(router).router)