from fastapi import Query, HTTPException
from typing import Optional

class Tasks:
    def __init__(self, router):
        self.router = router
        self.router.add_api_route(path="/task", endpoint=self.create_task, methods=["POST"], status_code=201)
        self.router.add_api_route(path="/task", endpoint=self.get_task, methods=["GET"], status_code=200)
        self.router.add_api_route(path="/tasks", endpoint=self.get_tasks, methods=["GET"], status_code=200)
        self.router.add_api_route(path="/task", endpoint=self.edit_task, methods=["PATCH"], status_code=200)
        self.router.add_api_route(path="/task", endpoint=self.delete_task, methods=["DELETE"], status_code=200)

    def create_task(self):
        return {"task": 'create_task'}

    def get_task(self, id: Optional[int] = Query(None, title='ID', description='ID of the task')):
        if id != None:
            return {"task": f'Find {id}'}
        else:
            return HTTPException(status_code=404, detail=f'Record with ID "{id}" does not exist!')

    def get_tasks(self, page: Optional[int] = Query(None, title='Page', description='Page of tasks list')):
        if page != None:
            return {"task": f'Tasks list on Page {page}'}
        else:
            return HTTPException(status_code=404, detail=f'Page "{page}" does not exist!')

    def edit_task(self, id: Optional[int] = Query(None, title='ID', description='ID of the task')):
        if id != None:
            return {"task": f'Edit {id}'}
        else:
            return HTTPException(status_code=404, detail=f'Record with ID "{id}" does not exist!')

    def delete_task(self, id: Optional[int] = Query(None, title='ID', description='ID of the task')):
        if id != None:
            return {"task": f'Delete {id}'}
        else:
            return HTTPException(status_code=404, detail=f'Record with ID "{id}" does not exist!')