from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class TaskModel(BaseModel):
    id: Optional[int] = None
    title: str
    description: str
    exp_time: datetime